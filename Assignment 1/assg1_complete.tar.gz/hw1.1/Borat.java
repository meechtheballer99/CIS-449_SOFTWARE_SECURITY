// This program prints some messages.
// Wah wah wee wah!

public class Borat {
    public static void main(String[] args) {
        System.out.println("Hello, my name-a Borat");
        System.out.println("Hello, my name-a Borat");
        System.out.println("I like-a you");
        System.out.println();
        System.out.println("Very nice!!!  \"I like!\"");
    }
}
